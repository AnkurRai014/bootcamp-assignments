import { Component, OnInit } from '@angular/core';
import { ChallanServiceService } from 'src/app/challan-service.service';
import { Challan } from 'src/app/common/challan';

@Component({
  selector: 'app-closed-challans',
  templateUrl: './closed-challans.component.html',
  styleUrls: ['./closed-challans.component.css']
})
export class ClosedChallansComponent implements OnInit {

  challans : Challan[];

  constructor(private service : ChallanServiceService) { }

  ngOnInit(): void {
    this.getDisputedChallan();
  }

  logout(){

  }

  getDisputedChallan(){
    this.service.getChallanByPoliceAndPaid(this.service.policeOfficer.personalId,true).subscribe(data=>{
      console.log(data);
      this.challans = data;
    })
  }

}
