export class Policeofficer {
  constructor(
   public personalId : bigint,
   public firstName : string,
	 public lastName : string,
	 public password : string
  ){}
}
