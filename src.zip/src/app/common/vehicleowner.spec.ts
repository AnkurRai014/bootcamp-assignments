import { Vehicleowner } from './vehicleowner';

describe('Vehicleowner', () => {
  it('should create an instance', () => {
    expect(new Vehicleowner()).toBeTruthy();
  });
});
