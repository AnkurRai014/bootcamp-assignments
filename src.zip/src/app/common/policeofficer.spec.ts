import { Policeofficer } from './policeofficer';

describe('Policeofficer', () => {
  it('should create an instance', () => {
    expect(new Policeofficer()).toBeTruthy();
  });
});
