import { Challan } from './challan';

describe('Challan', () => {
  it('should create an instance', () => {
    expect(new Challan()).toBeTruthy();
  });
});
