export class Vehicleowner {
   constructor(
  public vehiclePlateNumber : string,
	public firstName : string,
	public lastName  : string,
	public address  :  string,
	public phoneNumber : bigint,
	public password  : string
   ){}
}
